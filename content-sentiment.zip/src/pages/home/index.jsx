import React from "react";
import CompanyDetailsForm from "../../components/CompanyDetailsForm ";

const Home = () => {
  return (
    <div>
      <CompanyDetailsForm />
    </div>
  );
};

export default Home;
